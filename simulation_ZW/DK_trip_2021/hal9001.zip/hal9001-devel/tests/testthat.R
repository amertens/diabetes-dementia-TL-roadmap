library(testthat)
library(methods)
library(data.table)
library(microbenchmark)
library(glmnet)
library(SuperLearner)
library(hal9001)

test_check("hal9001")
